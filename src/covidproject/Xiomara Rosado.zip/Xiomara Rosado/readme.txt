The way you can access my project is with the user number I think is 16336 and the password xiomara in case you are a student, the way you can access as administrator is with the user jonh and the password 1234.
Unfortunately I didn't have time to create the access and classes for branch in the same way I didn't have time to create the different options for the students.
I learned a lot creating this project and I had the opportunity to create the most important thing which was administrator create access for students, new courses, delete us, the same way for new students who want to enroll in a new course.

channel https://www.youtube.com/watch?v=KLZw7q85znA