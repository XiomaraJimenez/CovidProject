
CREATE DATABASE CovidProjectDB;

# Use Database
USE CovidProjectDB;
CREATE TABLE Student (
	studentID int NOT NULL AUTO_INCREMENT,
	FirstName varchar(255) Not NULL,
	LastName varchar(255) NOT NULL,
    	Birthdate varchar(40),
    	Contacts varchar(40),
	Password varchar(20),
    	PRIMARY KEY (studentID)
);
ALTER TABLE Student ADD Password VARCHAR (20);

# Set increment starts at 1000
ALTER TABLE Student AUTO_INCREMENT=1000;

CREATE TABLE Faculty (
	facultyID int NOT NULL AUTO_INCREMENT,
	FirstName varchar(255) Not NULL,
	LastName varchar(255) NOT NULL,
    	Birthdate varchar(40),
    	Contacts varchar(40),
	Password varchar(20),
    	PRIMARY KEY (facultyID)
);
# Set increment starts at 2000
ALTER TABLE Faculty AUTO_INCREMENT=2000;


CREATE TABLE Exam(
	StudentID int(4) NOT NULL,
	Date varchar(12),
	Status varchar(12),
	result double(100, 5),
	CourseID int(4),
	FOREIGN KEY (StudentID) REFERENCES Student(StudentID) ON DELETE CASCADE
);

CREATE TABLE Assignment(
	StudentID int(4) NOT NULL,
	Date varchar(12),
	Status varchar(12),
	result double(100, 5),
	CourseID int(4),
	FOREIGN KEY (StudentID) REFERENCES Student(StudentID) ON DELETE CASCADE
);





use CovidProjectDB;
show tables;

select * from students;

insert into student values (16336,"Xiomara","Rosado","18-04-1991",0858197883,"xiomara");


select * from faculty;

insert into faculty values (16410052,"Xiomara","Rosado","18-04-1991",0858197883,"xiomara");